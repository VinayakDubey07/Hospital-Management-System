﻿# Hospital-management-system
 Live demo: https://bmsce-hospital.000webhostapp.com/
