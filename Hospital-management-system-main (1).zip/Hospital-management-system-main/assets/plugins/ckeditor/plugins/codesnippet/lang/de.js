/*
 Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","de",{button:"Codeschnipsel einfügen",codeContents:"Codeinhalt",emptySnippetError:"Ein Codeschnipsel darf nicht leer sein.",language:"Sprache",title:"Codeschnipsel",pathName:"Codeschnipsel"});